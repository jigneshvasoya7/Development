# -*- coding: utf-8 -*-
# Sanskrit Noun Vibhakti Identification application includes following processing steps (More steps will be added in
# future).
# 1) Read input file
# 2) Language Detection
# 3) Sentence Segmentation
# 4) Word Segmentation
# 5) Load (Verb and Avyaya) Dataset
# 6) Word Tagging for Punctuation, Verb and Avyaya

##### Application Start ######
# Import Utilities
from Src import Utility
from Src import Database
import morfessor

IoMorfessor = morfessor.MorfessorIO()

# Path of input data
PathDataInput = 'Data/Input/ex.txt'
# PathDataInput = 'Data/Input/noun.txt'

# Path of database
PathDatabaseVerb = 'Data/Database/verb.txt'
PathDatabaseAvyaya = 'Data/Database/avyaya.txt'
PathDatabaseNoun = 'Data/Database/noun.txt'
PathDatabaseNounException = 'Data/Database/exception.txt'
PathDatabaseGender = 'Data/Database/gender.txt'

# Path of mapping database
PathMappingSuffix = 'Data/Mapping/SuffixMapping.txt'
PathMappingCase = 'Data/Mapping/CaseMapping.txt'
PathMappingNumber = 'Data/Mapping/NumberMapping.txt'
PathMappingEnding = 'Data/Mapping/EndingMapping.txt'
PathMappingGender = 'Data/Mapping/GenderMapping.txt'


# 1)  Read input file
DataInput = Utility.LoadInput(PathDataInput)
# DataInput = u'अथर्वाङ्गिरस'
# DataInput = u'अक्षता'

if DataInput is False:
    exit()

# 2) Language Detection
Language = Utility.DetectLanguage(DataInput)
if Language is False:
    exit()

print "\nDetected Language is: ",Language

if Language != u'Sanskrit':
    print "Warning: Wrong input language, Please input Sanskrit language"
    # exit()

print "\n\nDisplay Input Data\n"
print DataInput

# Load Sanskrit model for morphological analysis
ModelMorfessor = IoMorfessor.read_any_model('MorphoModel/sa.docs.txt.counts.pkl')

# 3) Sentence Segmentation
SentenceList = Utility.SegmentSentence(DataInput)

if SentenceList is False:
    exit()

print "\n\nDisplay Sentence List\n"
Utility.DisplayData(SentenceList)

# 4) Word Segmentation
WordListSentenceWise = []
WordList = Utility.SegmentWord(DataInput,WordListSentenceWise)

if WordList is False:
    exit()

print "\n\nDisplay Word List\n"
Utility.DisplayData(WordList)

# 5) Load Datasets

# Load Database
DatabaseVerb = Database.LoadDatabase(PathDatabaseVerb)
DatabaseAvyaya = Database.LoadDatabase(PathDatabaseAvyaya)
DatabaseNoun = Database.LoadDatabase(PathDatabaseNoun)
DatabaseNounException = Database.LoadDatabase(PathDatabaseNounException)
DatabaseGender = Database.LoadDatabase(PathDatabaseGender)

#Load Mappings
MappingSuffix = Database.LoadDatabase(PathMappingSuffix)
MappingCase = Database.LoadDatabase(PathMappingCase)
MappingNumber = Database.LoadDatabase(PathMappingNumber)
MappingEnding = Database.LoadDatabase(PathMappingEnding)
MappingGender = Database.LoadDatabase(PathMappingGender)


# Create Dictionary
# For database
DictDatabaseVerb = Database.CreateDictionay(DatabaseVerb,DictKeyValue = u'Verb')
DictDatabaseAvyaya = Database.CreateDictionay(DatabaseAvyaya, DictKeyValue = u'Avyaya')
DictDatabaseNoun = Database.CreateDictionay(DatabaseNoun, DictKeyValue = u'Noun')
DictDatabaseNounException = Database.CreateDictionay(DatabaseNounException)
DictDatabaseGender = Database.CreateDictionay(DatabaseGender)
# For Mappings
DictMappingCase = Database.CreateDictionay(MappingCase)
DictMappingNumber = Database.CreateDictionay(MappingNumber)
DictMappingEnding = Database.CreateDictionay(MappingEnding)
DictMappingGender = Database.CreateDictionay(MappingGender)

ListSuffix, ListSuffixMapping  = Database.CreateListMapping(MappingSuffix)
ListGender, ListGenderMapping  = Database.CreateListMapping(DatabaseGender)


# Create Dictionary of word list
DictWordList = Database.CreateDictionay(WordList)


# 6) Word Tagging for Punctuation, Verb and Avyaya
DictWordListTag = DictWordList.copy()
Utility.UpdateDictIfMatchFound(DictWordList,DictWordListTag,Utility.DictPunctuationList)
Utility.UpdateDictIfMatchFound(DictWordList,DictWordListTag,DictDatabaseVerb)
Utility.UpdateDictIfMatchFound(DictWordList,DictWordListTag,DictDatabaseAvyaya)
Utility.UpdateDictIfMatchFound(DictWordList,DictWordListTag,DictDatabaseNounException)
Utility.UpdateDictIfMatchFound(DictWordList,DictWordListTag,DictDatabaseNoun,RemoveEntry=False)

for key in DictWordList.keys():
    # Perform morphological analysis (Process further if key is separated)
    Morphemes = ModelMorfessor.viterbi_segment(key)[0]
    # if len(Morphemes) < 2:
    #     continue

    lenMaxMatch = 0
    suffixMatched = u''
    ListSuffixKeyMappping = []
    for suffix,mapping in zip(ListSuffix,ListSuffixMapping):
        if Utility.FindEndingSubString(suffix,key):
            if len(suffix) > lenMaxMatch:
                lenMaxMatch = len(suffix)
                # Clear Value list and Append
                ListSuffixKeyMappping = []
                ListSuffixKeyMappping.append(mapping)

                # suffixMatched = suffix
                # DictWordListTag[key] = mapping
            elif len(suffix) == lenMaxMatch:
                # Append mappping in  Value list
                ListSuffixKeyMappping.append(mapping)

                # lenMaxMatch = len(suffix)
                # suffixMatched = suffix
                # DictWordListTag[key] = mapping

    # Get Key Mapping
    if ListSuffixKeyMappping:
        ListSuffixVibhktiMapping = []
        for Key in ListSuffixKeyMappping:

            KeyMapping = Utility.ConvertSuffixKeyToMapping(Key,DictMappingCase,DictMappingNumber,DictMappingEnding,DictMappingGender)
            if KeyMapping:
                ListSuffixVibhktiMapping.append(KeyMapping)

        DictWordListTag[key] =  ListSuffixVibhktiMapping



print "\n\nDisplay Output"
Utility.DisplayDictData(DictWordListTag)
