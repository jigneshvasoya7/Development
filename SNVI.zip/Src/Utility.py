# -*- coding: utf-8 -*-
import os
import codecs
from polyglot.detect import Detector
from polyglot.text import Text

# Punctuation Unicode (utf-8) range: U+0021 to U+002F
strPunct = u'Punct'
DictPunctuationList = {u'.':strPunct,
                       u',':strPunct,
                       u'।':strPunct,
                       u'।।':strPunct}

def LoadInput(FileName = 'Data/Input/ex1.txt'):

    if not (os.path.exists(FileName)):
        print "Warning: File not found: {}".format(FileName)
        return False

    Data = u''
    # dataFemale = []

    # Read unicode data from .txt file
    # Use encoding='utf-8-sig' instead of encoding='utf-8' to avoid BOM (Byte order marker) character while reading unicode
    # data from file.
    f = codecs.open(FileName, encoding='utf-8-sig')
    for line in f:
        Data = Data + line
        # if len(line) != len(line.rstrip('\r\n')):
        #     Data = Data + line.rstrip('\r\n') + u' '
        # else:
        #     Data = Data + line

    f.close()
    return Data


def DetectLanguage(Data = None):
    if not Data:
        print "Warning: Empty Data"
        return False

    detector = Detector(Data)
    return detector.language.name


def SegmentSentence (Data):
    if not Data:
        print "Warning: Empty Data"
        return False

    SentenceList = Text(Data).sentences
    return SentenceList


def SegmentWord(Data, WordListSentenceWise = []):
    if not Data:
        print "Warning: Empty Data"
        return False

    SentenceList = SegmentSentence(Data)
    WordList = []
    for Sentence in SentenceList:
        WordListSentenceWise.append(Sentence.words)
        for word in Sentence.words:
            WordList.append(unicode(word))

    return WordList


def DisplayData(Data):
    if not Data:
        print "Warning: Empty Data"
        return False

    for cnt, data in zip(range(0, len(Data)), Data):
        print(u"Data[{}]: {}".format(cnt, data))


def DisplayDictData(DictData):
    if not DictData:
        print "Warning: Empty Data"
        return False

    # for cnt, data in zip(range(0, len(DictData)), DictData.iteritems()):
    #     print(u"Data[{}]: Word:{} Tag:{}".format(cnt, data[0], data[1]))
    for cnt, data in zip(range(1, len(DictData)+1), DictData.iteritems()):

        if len(data[1]) < 1:
            print(u"\nWord Index[{}]: Word:{} Tag: {} ".format(cnt, data[0],u'Not Found'))
            continue
        elif len(data[1]) == 1:
            print(u"\nWord Index[{}]: Word:{} Tag: {} ".format(cnt, data[0], data[1][0]))
            continue
        else:
            print(u"\nWord Index[{}]: Word:{}".format(cnt, data[0]))

        for tagno, keyValue in zip(range(1, len(data[1])+1), data[1]):
            print(u"Tag[{}]: {} ".format(tagno, keyValue))


def UpdateDictIfMatchFound(SrcDictWordList, SrcDictWordListTag, MatchDictList = DictPunctuationList, RemoveEntry = True):

    for key in SrcDictWordList.keys():
        if key in MatchDictList:
            SrcDictWordListTag[key] = [MatchDictList[key]]
            if RemoveEntry:
                SrcDictWordList.pop(key)
        else:
            SrcDictWordListTag[key] = [u'Not Found']


def FindSubString(Word, String):
    lenWord = len(Word)
    Found = False
    for i in range(len(String) - lenWord + 1):
        if String[i: i + lenWord] == Word:
            Found = i

    return Found


def FindEndingSubString(Word, String):
    if len(Word) > len(String):
        return False

    if String[- len(Word):] == Word:
        return True
    else:
        return False

def ConvertSuffixKeyToMapping(key,DictMappingCase,DictMappingNumber,DictMappingEnding,DictMappingGender):
    KeyMapping = u''
    if not key or (len(key) != 4):
        return False

    if key[0] in DictMappingCase.keys():
        KeyMapping = KeyMapping +  DictMappingCase[key[0]] + ' '

    if key[1] in DictMappingNumber.keys():
        KeyMapping = KeyMapping + DictMappingNumber[key[1]] + ' '

    if key[2] in DictMappingEnding.keys():
        KeyMapping = KeyMapping + DictMappingEnding[key[2]] + ' '

    if key[3] in DictMappingGender.keys():
        KeyMapping = KeyMapping + DictMappingGender[key[3]]

    return KeyMapping