import os
import codecs

# Read unicode data from .txt file
# Use encoding='utf-8-sig' instead of encoding='utf-8' to avoid BOM (Byte order marker) character while reading unicode
# data from file.
encodings = ['utf-8-sig','utf-16','utf-32']

def LoadDatabase(FileName = 'Data/Database/verb.txt'):
    ReadSuccess = False
    global f
    for e in encodings:
        try:
            f = codecs.open(FileName, encoding=e)
            f.readlines()
            f.seek(0)
        except UnicodeDecodeError:

            # continue
            print '{} File is failed to open with encoding: {}'.format(FileName,e)
        else:
            print '{} File is opened with encoding: {}'.format(FileName,e)
            ReadSuccess = True
            break

    if ReadSuccess is False:
        print "LoadDatabase is Failed"
        return False

    Data = []
    for line in f:
        Data.append(line.rstrip('\r\n'))

    f.seek(0)
    f.close()
    return Data

def CreateDictionay(DataListUnicode,DictKeyValue = u''):
    DictData = {}
    for DataTemp in DataListUnicode:
        DataTemp = unicode(DataTemp).split(u'\t')
        if len(DataTemp) is 2:
            DictData.update({DataTemp[0]: DataTemp[1]})

        if len(DataTemp) is 1:
            DictData.update({DataTemp[0]:DictKeyValue})

    return DictData


def CreateListMapping(DataListUnicode,DictKeyValue = u''):
    ListDataKey = []
    ListDataMapping = []
    for DataTemp in DataListUnicode:
        DataTemp = unicode(DataTemp).split(u'\t')
        if len(DataTemp) is 2:
            ListDataKey.append(DataTemp[0])
            ListDataMapping.append(DataTemp[1])

        if len(DataTemp) is 1:
            ListDataKey.append(DataTemp[0])
            ListDataMapping.append(DictKeyValue)

    return ListDataKey,ListDataMapping


def SearchDictionay(DictData,DictKey = u''):
    if DictKey in DictData:
        return DictData[DictKey]
    else:
        return False