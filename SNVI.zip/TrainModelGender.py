# -*- coding: utf-8 -*-

from Src import Database
import nltk
import random

def GenderFeatures(word):
    # return {'last_letter': word[-2:]}
    return {'last_letter': word[-1]}

# Percentage of train and test dataset
ClassNames = [u'पुंलिङ्ग',u'स्त्रीलिङ्ग',u'नपुंसकलिङ्ग']
TotalClasses = len(ClassNames)
PercTrainIndividualClass =  0.8


# Path of database
PathDatabaseMasculine = 'Data/Database/genderMasculine.txt'
PathDatabaseFeminine = 'Data/Database/genderFeminine.txt'
PathDatabaseNeuter = 'Data/Database/genderNeuter.txt'

# Load Database
DatabaseMasculine = Database.LoadDatabase(PathDatabaseMasculine)
DatabaseFeminine = Database.LoadDatabase(PathDatabaseFeminine)
DatabaseNeuter = Database.LoadDatabase(PathDatabaseNeuter)

ListMasculine, ListMasculineMapping  = Database.CreateListMapping(DatabaseMasculine)
ListFeminine, ListFeminineMapping  = Database.CreateListMapping(DatabaseFeminine)
ListNeuter, ListNeuterMapping  = Database.CreateListMapping(DatabaseNeuter)

SizeTrainMasculine = int(len(ListMasculine) * PercTrainIndividualClass)
SizeTrainFeminine = int(len(ListFeminine) * PercTrainIndividualClass)
SizeTrainNeuter = int(len(ListNeuter) * PercTrainIndividualClass)

# Randomize the dataset list
random.shuffle(ListMasculine)
random.shuffle(ListFeminine)
random.shuffle(ListNeuter)

TrainListMasculine = ListMasculine[:SizeTrainMasculine]
TrainListFeminine = ListFeminine[:SizeTrainFeminine]
TrainListNeuter = ListNeuter[:SizeTrainNeuter]

TestListMasculine = ListMasculine[SizeTrainMasculine:]
TestListFeminine = ListFeminine[SizeTrainFeminine:]
TestnListNeuter = ListNeuter[SizeTrainNeuter:]

TrainLabeledSet = ([(name,ClassNames[0]) for name in TrainListMasculine] +
                   [(name,ClassNames[1] ) for name in TrainListFeminine] +
                   [(name,ClassNames[2] ) for name in TrainListNeuter])

TestLabeledSet = ([(name, ClassNames[0]) for name in TestListMasculine] +
                  [(name, ClassNames[1]) for name in TestListFeminine] +
                  [(name, ClassNames[2]) for name in TestnListNeuter])

# Train naive bayes classifier
TrainFeatureSet = [(GenderFeatures(n), gender) for (n, gender) in TrainLabeledSet]
TestFeatureSet = [(GenderFeatures(n), gender) for (n, gender) in TestLabeledSet]

classifier = nltk.NaiveBayesClassifier.train(TrainFeatureSet)

print "Classifier Traing Accuracy is: {}".format(nltk.classify.accuracy(classifier,TrainFeatureSet))
print "Classifier Testing Accuracy is: {}".format(nltk.classify.accuracy(classifier,TestFeatureSet))


ResultTestMasculine = [(name, classifier.classify(GenderFeatures(name))) for name in TestListMasculine]
ResultTestFeminine = [(name, classifier.classify(GenderFeatures(name))) for name in TestListFeminine]
ResultTestNeuter = [(name, classifier.classify(GenderFeatures(name))) for name in TestnListNeuter]



# Testing Accuracy Calculation
TP = 0.0
for result in ResultTestMasculine:
    if result[1] == ClassNames[0]:
        TP = TP + 1
Accuracy = round((TP/len(ResultTestMasculine)) * 100,ndigits=2)
print "Result Gender Identification (Masculine) : {} Perc",format(Accuracy)

TP = 0.0
for result in ResultTestFeminine:
    if result[1] == ClassNames[1]:
        TP = TP + 1
Accuracy = round((TP/len(ResultTestFeminine)) * 100,ndigits=2)
print "Result Gender Identification (Feminine) : {} Perc",format(Accuracy)

TP = 0.0
for result in ResultTestNeuter:
    if result[1] == ClassNames[2]:
        TP = TP + 1
Accuracy = round((TP/len(ResultTestNeuter)) * 100,ndigits=2)
print "Result Gender Identification (Neuter) : {} Perc",format(Accuracy)

TestIndex = 0
print classifier.classify(GenderFeatures(TestListMasculine[TestIndex]))
print classifier.classify(GenderFeatures(TestListFeminine[TestIndex]))
print classifier.classify(GenderFeatures(TestnListNeuter[TestIndex]))


# Store Trained Model
import pickle

# Store Trained model (in drive) using joblib
from sklearn.externals import joblib

# Store trained model
joblib.dump(classifier,'sa_GenderIdentification.pkl')

# Load saved model
classifierLoad = joblib.load('sa_GenderIdentification.pkl')

print 'Result Model loaded: ',classifierLoad.classify(GenderFeatures(TestListMasculine[TestIndex]))